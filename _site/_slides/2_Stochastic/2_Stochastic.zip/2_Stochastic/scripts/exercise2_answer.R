library(tidyverse)
library(cowplot)
library(pomp)
theme_set(theme_cowplot())

## Read in the Measles Data
read_csv("raw-data/Measles_Consett_1948.csv") |> 
  select(week,reports=cases) -> meas
meas |> as.data.frame() |> head(n=3)

## Plot the data
meas |>
  ggplot(aes(x=week,y=reports)) +
  geom_line() +
  geom_point() +
  background_grid(major='xy')


# Code the SEIR model ----------------------------------------------
## Specify the process model
seir_stoch <- Csnippet("
  double dN_SI = rbinom(S,1-exp(-Beta*I/N*dt));
  double dN_EI = rbinom(E,1-exp(-Sigma*dt));
  double dN_IR = rbinom(I,1-exp(-Gamma*dt));
  S -= dN_SI;
  E += dN_SI - dN_EI;
  I += dN_EI - dN_IR;
  R += dN_IR;
  H += dN_IR;
")

## Specify initial model conditions
seir_rinit <- Csnippet("
  S = nearbyint(Eta*N);
  E = 0;
  I = 1;
  R = nearbyint((1-Eta)*N);
  H = 0;
")

## Specify the measurement model
seir_dmeas <- Csnippet("
  lik = dnbinom_mu(reports, k, Rho*H, give_log);
")

seir_rmeas <- Csnippet("
  reports = rnbinom_mu(k, Rho*H);
")

## Create the SEIR pomp model
meas |>
  pomp(
    times = 'week',
    t0 = 0,
    rprocess = euler(seir_stoch, delta.t=1/7),
    rinit = seir_rinit,
    rmeasure = seir_rmeas,
    dmeasure = seir_dmeas,
    accumvars = "H",
    statenames = c("S","E","I","R","H"),
    paramnames = c("Sigma", "Beta","Gamma","N","Eta","Rho","k")
  ) -> measSEIR

## Specify the parameters
c(Sigma = 0.5,
  Beta = 15, 
  Gamma = 1, 
  Rho = .95, 
  k = 10,
  Eta = 0.1, 
  N = 38000) -> meas_seir_params

## Run the simulations and plot them out - do they fit any better?
measSEIR |>
  simulate(
    params=meas_seir_params,
    nsim=50, format="data.frame", include.data=TRUE) |> 
  mutate(value_type = ifelse( .id =='data', 'data', 'simulation')) |>
  ggplot(aes(week, reports, group = .id, color = value_type, alpha = value_type)) +
  geom_line() +
  background_grid(major = 'xy') +
  scale_color_brewer(type = 'qual', palette = 2) +
  scale_alpha_manual(values = c(1, 0.4)) +
  labs(x = 'Week', y = "Reported cases", color = "", alpha = "")





