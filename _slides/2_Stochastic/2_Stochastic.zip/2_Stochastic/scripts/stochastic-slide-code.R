library(tidyverse)
library(cowplot)
library(pomp)
theme_set(theme_cowplot())

set.seed(808)
# Specify the pomp model --------------------------------------------------
## Create the deterministic skeleton for the basic SIR model
det_skel <- Csnippet("
                      DS = -Beta*S*I/N; 
                      DI = Beta*S*I/N - I*Gamma;
                      DNI = Beta*S*I/N;
                      DC = Beta*S*I/N*Rho;
                      DR = I*Gamma;
                    ")

statenames <- c("S", "I", "NI", "C", "R", "N")
paramnames <- c("Beta", "Gamma", "Rho")


## Specify the parameters and initial conditions for the run
initN <- 1000
initI <- 2
initS <- initN - initI

rinit <- Csnippet(sprintf("
                         S = %d;
                         I = %d;
                         NI = 0;
                         C = 0;
                         R = 0;
                         N = %d;
                        ",initS, initI, initN))

params <- c(Beta = 1/2, Gamma = 1/7, Rho= 0.5)


trajectory(t0 = 0,
           times = 1:75,
           params = params,
           skeleton = vectorfield(det_skel),
           accumvars = c("NI", "C"),
           rinit = rinit,
           statenames=statenames,
           paramnames=paramnames,
           format="data.frame"
          ) -> sir_trajectory

## Print out the resulting epidemic
sir_trajectory

## Make a plot of the dynamics
sir_trajectory |> 
  as_tibble() |> 
  select(-.id, -N) |> 
  pivot_longer(cols = !time) |> 
  ggplot(aes(time, value, color = name)) + 
  geom_line() +
  labs(x = 'Day of simulation', y ='Compartment population', color = "") +
  scale_color_brewer(type = 'qual', palette = 2) -> sir_compartment_plot
sir_compartment_plot

save_plot('figures/sir_compartment_plot.png', sir_compartment_plot, base_height = 3.5, base_asp = 1.8, bg = 'white')


# Gillespie algorithm in pomp ---------------------------------------------
pomp(
  data=data.frame(
    time=seq(1,60,by=1),
    C=NA
  ),
  times="time",t0=0,
  rprocess=gillespie_hl(
    infection=list("rate=Beta*S*I/N;",c(N=0,S=-1,I=1,R=0,NI=1)),
    recovery=list("rate=Gamma*I;",c(N=0,S=0,I=-1,R=1,NI=0)),
    hmax=1
  ),
  rmeasure=Csnippet("C=rbinom(NI, Rho);"),
  paramnames=c("Rho","Beta","Gamma"),
  statenames=c("N","S","I","R","NI"),
  accumvars=c("NI"),
  params=c(S.0=998,I.0=2,R.0=0,N.0=1000,NI.0=0,
           Beta=1/2,Gamma=1/7,Rho=0.5)
) -> sir_gillespie

simulate(sir_gillespie,nsim=20,format="data.frame") -> sir_gillespie_sims

## Plot the simulations
sir_gillespie_sims |> 
  as_tibble() |> 
  select(-N) |> 
  mutate(.id = as.numeric(.id)) |> 
  pivot_longer(cols = !time & !.id) |> 
  ggplot(aes(x=time,y=value,group=.id,color=.id))+
  geom_line()+
  guides(color=FALSE)+
  facet_grid(name~.,scales="free_y") +
  scale_color_viridis_c() +
  labs(x = "Day of simulation", y = "Compartment population" ) -> sir_gillespie_sims_plot
sir_gillespie_sims_plot

## Plot the simulations compared to the deterministic model results
sir_gillespie_sims |> 
  as_tibble() |> 
  select(-N) |> 
  mutate(.id = as.numeric(.id)) |> 
  pivot_longer(cols = !time & !.id) |> 
  ggplot(aes(x=time,y=value,group=.id,color=.id))+
  geom_line(alpha=.5)+
  guides(color='none')+
  facet_grid(name~.,scales="free_y") +
  scale_color_viridis_c() +
  geom_line(data = sir_trajectory |> 
              as_tibble() |> 
              filter(time<=60) |> 
              select(-.id, -N) |> 
              pivot_longer(cols = !time), aes(time, value), inherit.aes=F, color = "Black", linewidth = 0.8) +
  labs(x = "Day of simulation", y = "Compartment population" ) -> sir_gillespie_sims_det_comp_plot
sir_gillespie_sims_det_comp_plot

## Save plots
save_plot('figures/sir_gillespie_sims_plot.png', 
          sir_gillespie_sims_plot, base_height = 6, base_asp = 0.9,bg='white')
save_plot('figures/sir_gillespie_sims_det_comp_plot.png', 
          sir_gillespie_sims_det_comp_plot, base_height = 6, base_asp = 0.9,bg='white')


# Setup the measles example -----------------------------------------------
## Read in the Measles Data
read_csv("raw-data/Measles_Consett_1948.csv") |> 
  select(week,reports=cases) -> meas
meas |> as.data.frame() |> head(n=3)

## Plot the data
meas |>
  ggplot(aes(x=week,y=reports)) +
  geom_line() +
  geom_point() +
  background_grid(major='xy') -> measles_data_plot
measles_data_plot
save_plot('figures/measles_data_plot.png', 
          measles_data_plot, 
          base_height = 3.5, base_asp = 1.8, bg = 'white')



# Code measles  model in R -------------------------------------------------
## Specify the process model
sir_stoch <- function (S, I, R, N, H, Beta, Gamma, delta.t, ...) {
  dN_SI <- rbinom(n=1,size=S,prob=1-exp(-Beta*I/N*delta.t))
  dN_IR <- rbinom(n=1,size=I,prob=1-exp(-Gamma*delta.t))
  S <- S - dN_SI
  I <- I + dN_SI - dN_IR
  R <- R + dN_IR
  H <- H + dN_IR
  c(S = S,  I = I,  R = R,  H = H)
}

## Initialization of states for model
## Eta is a parameter that controls the fraction of the population initially susceptible
sir_rinit <- function (N, Eta, ...) {
  c(S = round(N*Eta), 
    I = 1, 
    R = round(N*(1-Eta)), 
    H = 0)
}

## Create the measurement (observation) model
## Rho indicates the proportion of the infections that are reported
## reports is the name of the column in our measles dataframe
## k is the dispersion parameter for the negative binomial model
sir_dmeas <- function (reports, H, Rho, k, log, ...) {
  dnbinom(x=reports, size=k, mu=Rho*H, log=log)
}

sir_rmeas <- function (H, Rho, k, ...) {
  c(reports=rnbinom(n=1, size=k, mu=Rho*H))
}

## Initialize the model
meas |>
  pomp(
    times="week",
    t0=0,
    rprocess=euler(sir_stoch, delta.t=1/7),
    rinit=sir_rinit,
    rmeasure = sir_rmeas,
    dmeasure = sir_dmeas,
    accumvars = "H"
  ) -> measSIR

##Simulate the model according to a reasonable set of parameters
c(Beta=7.5, 
   Gamma=0.5, 
   Rho=.95, 
   k=10,
   Eta=0.1, 
   N=38000) -> meas_params

measSIR |> 
  simulate(
    params = meas_params,
    nsim=20,format="data.frame",
    include.data=TRUE
  ) -> meas_sims_R

meas_sims_R |> 
  mutate(value_type = ifelse( .id =='data', 'data', 'simulation')) |>
  ggplot(aes(week, reports, group = .id, color = value_type, alpha = value_type)) +
  geom_line() +
  background_grid(major = 'xy') +
  scale_color_brewer(type = 'qual', palette = 2) +
  scale_alpha_manual(values = c(1, 0.4)) +
  labs(x = 'Week', y = "Reported cases", color = "", alpha = "") -> measles_sims_R_plot
measles_sims_R_plot
save_plot('figures/measles_sims_R_plot.png', 
          measles_sims_R_plot, 
          base_height = 3.5, base_asp = 1.8, bg = 'white')


# Code measles  model in CSnippet ----------------------------------------------
## Specify the process model
sir_stoch <- Csnippet("
  double dN_SI = rbinom(S,1-exp(-Beta*I/N*dt));
  double dN_IR = rbinom(I,1-exp(-Gamma*dt));
  S -= dN_SI;
  I += dN_SI - dN_IR;
  R += dN_IR;
  H += dN_IR;
")

## Specify initial model conditions
sir_rinit <- Csnippet("
  S = nearbyint(Eta*N);
  I = 1;
  R = nearbyint((1-Eta)*N);
  H = 0;
")

## Specify the measurement model
sir_dmeas <- Csnippet("
  lik = dnbinom_mu(reports, k, Rho*H, give_log);
")

sir_rmeas <- Csnippet("
  reports = rnbinom_mu(k, Rho*H);
")


## Create the C snippet pomp model
measSIR |>
  pomp(
    rprocess = euler(sir_stoch, delta.t=1/7),
    rinit = sir_rinit,
    rmeasure = sir_rmeas,
    dmeasure = sir_dmeas,
    accumvars = "H",
    statenames = c("S","I","R","H"),
    paramnames = c("Beta","Gamma","N","Eta","Rho","k")
  ) -> measSIR_C

##Create functions for benchmarking the simulation speed performance
fR <- function() {measSIR |>
    simulate(
      params=meas_params,
      nsim=100,format="data.frame",include.data=TRUE
    )} 
fC <- function() {measSIR_C |>
    simulate(
      params=meas_params,
      nsim=100,format="data.frame",include.data=TRUE
    )} 

## Run a speed benchmark
library(microbenchmark)
res <- microbenchmark(fR(), fC(), times=100)

##Plot out the speed results
ggplot(res, aes(x=expr, y = time/1000000, color=expr)) +
  geom_boxplot(outliers = FALSE) +
  scale_color_brewer(palette="Dark2") +
  scale_x_discrete(labels = c("fR()" = "R", "fC()" = "CSnippet")) +
  scale_y_log10() + 
  labs(y = "time (milliseconds)", x = NULL) +
  theme_bw() + 
  guides(color="none") -> csnippet_speed_improvement_plot
csnippet_speed_improvement_plot

save_plot('figures/csnippet_speed_improvement_plot.png', 
          csnippet_speed_improvement_plot, 
          base_height = 4, base_asp = 1.3, bg = 'white')


# Visualize simulations for new parameters --------------------------------
## Specify new parameters
c(Beta=7.5, 
  Gamma=0.5, 
  Rho=.95, 
  k=10,
  Eta=0.05, 
  N=38000) -> meas_params

## Run the simulations
measSIR_C |>
  simulate(
    params=meas_params,
    nsim=20, format="data.frame", include.data=TRUE
  ) -> meas_sims_C

## Check the fit of the simulations
meas_sims_C |> 
  mutate(value_type = ifelse( .id =='data', 'data', 'simulation')) |>
  ggplot(aes(week, reports, group = .id, color = value_type, alpha = value_type)) +
  geom_line() +
  background_grid(major = 'xy') +
  scale_color_brewer(type = 'qual', palette = 2) +
  scale_alpha_manual(values = c(1, 0.4)) +
  labs(x = 'Week', y = "Reported cases", color = "", alpha = "") -> measles_sims_C_plot
measles_sims_C_plot
save_plot('figures/measles_sims_C_plot.png', 
          measles_sims_C_plot, 
          base_height = 3.5, base_asp = 1.8, bg = 'white')
