library(tidyverse)
library(cowplot)
library(pomp)

theme_set(theme_cowplot())

## Read in the Measles Data
read_csv("raw-data/Measles_Consett_1948.csv") |>
  select(week, reports = cases) -> meas

meas |> 
  as.data.frame() |> 
  head(n = 3)

## Plot the data
meas |>
  ggplot(aes(x = week, y = reports)) +
  geom_line() +
  geom_point() +
  background_grid(major = "xy")


# Code the SEIRS model ---------------------------------------------

## Specify the process model
seirs_stoch <- Csnippet("
  double dN_SI = rbinom(S, 1-exp(-Beta*I/N*dt));
  double dN_EI = rbinom(E, 1-exp(-Sigma*dt));
  double dN_IR = rbinom(I, 1-exp(-Gamma*dt));
  double dN_RS = rbinom(R, 1-exp(-alpha*dt));

  S += dN_RS - dN_SI;
  E += dN_SI - dN_EI;
  I += dN_EI - dN_IR;
  R += dN_IR - dN_RS;

  H += dN_IR;
")

## Specify initial model conditions
seirs_rinit <- Csnippet("
  S = nearbyint(Eta*N);
  E = 0;
  I = 1;
  R = nearbyint((1-Eta)*N);
  H = 0;
")

## Specify the measurement model
seirs_dmeas <- Csnippet("
  lik = dnbinom_mu(reports, k, Rho*H, give_log);
")

seirs_rmeas <- Csnippet("
  reports = rnbinom_mu(k, Rho*H);
")

## Create the SEIRS pomp model
meas |>
  pomp(
    times = "week",
    t0 = 0,
    rprocess = euler(seirs_stoch, delta.t = 1/7),
    rinit = seirs_rinit,
    rmeasure = seirs_rmeas,
    dmeasure = seirs_dmeas,
    accumvars = "H",
    statenames = c("S", "E", "I", "R", "H"),
    paramnames = c(
      "Sigma", "Beta", "Gamma", "alpha",
      "N", "Eta", "Rho", "k"
    )
  ) -> measSEIRS

## Specify the parameters
c(
  Sigma = 0.5,
  Beta = 15,
  Gamma = 1,
  alpha = 1 / 52,  # average immunity duration of 52 weeks
  Rho = 0.95,
  k = 10,
  Eta = 0.1,
  N = 38000
) -> meas_seirs_params

## Run simulations and plot them
measSEIRS |>
  simulate(
    params = meas_seirs_params,
    nsim = 50,
    format = "data.frame",
    include.data = TRUE
  ) |>
  mutate(
    value_type = if_else(
      .id == "data",
      "data",
      "simulation"
    )
  ) |>
  ggplot(aes(x = week, y = reports, group = .id,
      color = value_type, alpha = value_type)) +
  geom_line() +
  background_grid(major = "xy") +
  scale_color_brewer(type = "qual", palette = 2) +
  scale_alpha_manual(values = c(data = 1, simulation = 0.4)) +
  labs(
    x = "Week",
    y = "Reported cases",
    color = "",
    alpha = ""
  )

