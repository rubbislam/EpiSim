library(tidyverse)
library(cowplot)
library(pomp)
theme_set(theme_cowplot())

## Read in the Measles Data
read_csv("raw-data/Measles_Consett_1948.csv") |> 
  select(week,reports=cases) -> meas
meas |> as.data.frame() |> head(n=3)

## Plot the data
meas |>
  ggplot(aes(x=week,y=reports)) +
  geom_line() +
  geom_point() +
  background_grid(major='xy')


# Code measles  model in CSnippet ----------------------------------------------
## Specify the process model
sir_stoch <- Csnippet("
  double dN_SI = rbinom(S,1-exp(-Beta*I/N*dt));
  double dN_IR = rbinom(I,1-exp(-Gamma*dt));
  S -= dN_SI;
  I += dN_SI - dN_IR;
  R += dN_IR;
  H += dN_IR;
")

## Specify initial model conditions
sir_rinit <- Csnippet("
  S = nearbyint(Eta*N);
  I = 1;
  R = nearbyint((1-Eta)*N);
  H = 0;
")

## Specify the measurement model
sir_dmeas <- Csnippet("
  lik = dnbinom_mu(reports, k, Rho*H, give_log);
")

sir_rmeas <- Csnippet("
  reports = rnbinom_mu(k, Rho*H);
")


## Create the C snippet pomp model
meas |>
  pomp(
    times = 'week',
    t0 = 0,
    rprocess = euler(sir_stoch, delta.t=1/7),
    rinit = sir_rinit,
    rmeasure = sir_rmeas,
    dmeasure = sir_dmeas,
    accumvars = "H",
    statenames = c("S","I","R","H"),
    paramnames = c("Beta","Gamma","N","Eta","Rho","k")
  ) -> measSIR

## Specify the parameters
c(Beta=7.5, 
  Gamma=0.5, 
  Rho=.95, 
  k=10,
  Eta=0.1, 
  N=38000) -> meas_params

## Run the simulations and plot them out
measSIR |>
  simulate(
    params=meas_params,
    nsim=20, format="data.frame", include.data=TRUE) |> 
  mutate(value_type = ifelse( .id =='data', 'data', 'simulation')) |>
  ggplot(aes(week, reports, group = .id, color = value_type, alpha = value_type)) +
  geom_line() +
  background_grid(major = 'xy') +
  scale_color_brewer(type = 'qual', palette = 2) +
  scale_alpha_manual(values = c(1, 0.4)) +
  labs(x = 'Week', y = "Reported cases", color = "", alpha = "")

## Try and come up with parameter combinations that give you as close of a match as possible to the data



# Exercise 2 --------------------------------------------------------------
## Use the space below to code and plot an SEIR model




