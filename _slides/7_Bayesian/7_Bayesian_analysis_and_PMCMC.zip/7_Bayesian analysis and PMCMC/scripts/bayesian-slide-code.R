library(tidyverse)
library(pomp)
library(cowplot)
library(coda)
theme_set(theme_cowplot())

## This reads in the main components of the pomp model
source('scripts/boarding-school-model.R')

# Checking the data -------------------------------------------------------
## Quickly look at data to see if it looks good
## In actuality B corresponds to a prevalence metric (total number of boys bed-confined)
## In our example we assume it's incidence and make the population larger
## This is because there are statistical issues with fitting to prevalence estimates 
## (similar issues to fitting to cumulative counts)
bsflu |>
  ggplot(aes(day, B)) + 
  geom_line() +
  background_grid(major = 'xy', minor = 'xy')


# Setting up model -----------------------------------------
## Let's build the model with the data
## We use euler process and simulate 12 steps per day
## This is the same as mif2 setup (haven't specified prior distributions yet)
bsflu %>%
  select(day,B) %>%
  pomp(
    times="day", 
    t0=0,
    rmeasure=rmeas,
    dmeasure=dmeas,
    rprocess=euler(rproc, delta.t=1/12),
    rinit=rinit,
    partrans=parameter_trans(fromEst=fromEst,toEst=toEst),
    accumvars = 'NI',
    statenames=statenames,
    paramnames=paramnames
  ) -> flu


# Validating the model ----------------------------------------------------
## Specify some reasonable numbers for each of the four parameters:
## R0 of 2, (beta/mu_I = 2, and 
##           1/mu_I meaning people are infectious for 1 day before being bed-confined)
## 90% of students are reported
## People are in bed on average for 3 days 
sim_params <- c(Beta = 2, ## Makes an R0 of 2 (beta/mu_I)
                mu_I = 1, ## average infectious period of 1 day (1/1)
                rho = 0.9, ## 90% of infections reported
                mu_R1 = 1/3)


# Setting up bayesian estimation ---------------------------------------------

## We now can specify the prior distribution for the three parameters in the model
## That we will estimate
## We use uniform distributions for all, and choose reasonable minima and maxima
#### note that you will likely want to run subsequent analyses to test the sensitivity
#### of the results to these priors, but okay for now to try out
priorDens <- Csnippet("
  lik = dunif(Beta, 1, 4, 1) +
        dunif(mu_I, 0.5, 3, 1) +
        dunif(rho, 0.5, 1, 1);
  if (!give_log) lik = exp(lik);
")

## Run a short pmcmc run with simulated parameters to make sure things look okay
## Uses the flu pomp model and adds the prior density, initial parameters we used before, 
## It also changes paramnames to only those parameters that are being estimated (not fixed)
## Nmcmc is the number of mcmc samples to obtain
## Np is the number of particles to use 
## proposal indicates how mcmc parameter search happens, here we are using a
## simple random walk with standard deviations for each of the parameters
## Can play around with the random walk to see how it impacts things, but
## you are looking for a reasonable starting place for decent chain mixing
bake('processed-data/test-chain-boarding.rds',
     seed=4689593,
     {
       flu |> ## Standard pomp object that has already been created 
         pomp(dprior = priorDens, ## Prior specified from previous slide
              params = sim_params, ## Parameter starting point
              paramnames=c("Beta","mu_I","rho")) |> ## Parameter names
         pmcmc(Nmcmc = 10000, ## Number of MCMC iterations
               Np = 200, ## Number of particles to use
               proposal = mvn_diag_rw(rw.sd = c(Beta=0.3, mu_I=0.3, rho=0.1))
         )
}) -> test_mcmc

## Diagnose initial mixing
## A few notes, here you are just looking to see some movement of chains, and that the
## loglik is increasing roughly each iteration - in our case our initial parameters 
## are pretty good so not as much loglik movement
## in general increasing the particles increases the acceptance rate
## Decreasing the standard deviation of the parameter random walk does the same.

## Autocorrelation ideally would be close to 0 for the lag you use for thinning the chains
test_mcmc |> 
  traces() |>  
  autocorr.diag(lags=c(10, 50, 100))

## 1 minus the rejection rate is how often parameter jumps are accepted
## Ideally looking for something ~15-35%
test_mcmc |> traces() |> rejectionRate()

## Plot out the traceplot
test_mcmc |> traces() |> as_tibble() |> 
  select(loglik,Beta, mu_I, rho) |> 
  mutate(iteration = seq_along(loglik)) |> 
  pivot_longer(cols = !iteration) |> 
  ggplot(aes(iteration, value)) +
  geom_line() +
  facet_wrap(~name, scales = 'free_y')

## A simpler but less nice visualization :)
test_mcmc |> traces() |> traceplot() ##traces function turns the pomp output into mcmc object for coda

## These don't look "good" but they are sufficient 
## to give us confidence to move to main chain runs
## We are going to change our mixing to be based on the empirical acceptance variance/covariance matrix
## of the previous chains, which will improve the mixing dramatically


# Running the single improved chain ---------------------------------------
bake('processed-data/test-chain-boarding-empirical-proposal.rds',
     seed=35102343,
     {
       flu |>
         pomp(dprior = priorDens,
              params = sim_params, ##Using the sim params as a starting spot
              paramnames=c("Beta","mu_I","rho")) |>
         pmcmc(Nmcmc = 10000,
               Np = 200,
               proposal = mvn_rw(covmat(test_mcmc, thin = 50))
         )
     }) -> test_mcmc2

## Plot out the improved traceplot
test_mcmc2 |> traces() |> as_tibble() |> 
  select(loglik,Beta, mu_I, rho) |> 
  mutate(iteration = seq_along(loglik)) |> 
  pivot_longer(cols = !iteration) |> 
  ggplot(aes(iteration, value)) +
  geom_line() +
  facet_wrap(~name, scales = 'free_y')

test_mcmc2 |> 
  traces() |>  
  autocorr.diag(lags=c(10, 50, 100))
